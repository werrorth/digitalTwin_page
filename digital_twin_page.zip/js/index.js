/*大屏*/
//自调用函数
(function () {
    // 1、页面一加载就要知道页面宽度计算
    var setFont = function () {
        // 因为要定义变量可能和别的变量相互冲突，污染，所有用自调用函数
        var html = document.documentElement;// 获取html
        // 获取宽度
        var width = html.clientWidth;

        // 判断
        if (width < 1024) width = 1024
        if (width > 1920) width = 1920
        // 设置html的基准值
        var fontSize = width / 80 + 'px';
        // 设置给html
        html.style.fontSize = fontSize;
    }
    setFont();
    // 2、页面改变的时候也需要设置
    // 尺寸改变事件
    window.onresize = function () {
        setFont();
    }
})();


//时间部分
 (function(){
   function showTime(){ var date = new Date()
    var week = date.getDay()
    var weekday;
    switch(week){
        case 0: weekday = '星期天';break;
        case 1: weekday = '星期一';break;
        case 2: weekday = '星期二';break;
        case 3: weekday = '星期三';break;
        case 4: weekday = '星期四';break;
        case 5: weekday = '星期五';break;
        case 6: weekday = '星期六';break;
    }
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var day= date.getDate()
    var hour = date.getHours()
    var minute = date.getMinutes()
    var second = date.getSeconds()
    var time_1=document.getElementById('time_day')
    var time_2 =document.getElementById('time_date')
    var time_3 =document.getElementById('weekday')
    time_1.innerHTML = hour +" : "+ minute +" : "+ (second<10?('0'+second):second )
    time_2.innerHTML =  year + '年' + month + "月" + day + '日'+' ' 
    time_3.innerHTML = weekday
    setTimeout(showTime,1000);
}
showTime()

})();

// circle chart
var circleDom = document.getElementById('circleChart');
var circleChart = echarts.init(circleDom);
var circle_option;
circle_option = {
  tooltip: {
    trigger: 'item'
  },
  legend: {
    top: '5%',
    left: 'center'
  },
  series: [
    {
     
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 10,
        borderColor: '#fff',
        borderWidth: 2
      },
      label: {
        show: false,
        position: 'center'
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 40,
          fontWeight: 'bold'
        }
      },
      labelLine: {
        show: false
      },
      data: [
        { value: 1048, name: 'Search Engine' },
        { value: 735, name: 'Direct' },
        { value: 580, name: 'Email' },
        { value: 484, name: 'Union Ads' },
        { value: 300, name: 'Video Ads' }
      ]
    }
  ]
};
circle_option && circleChart.setOption(circle_option);

//wind chart
{
  var windOption={
    tooltip:{},
    radar:{
        indicator:[
            {name:'N',max:12},
            {name:'NNW',max:12},
            {name:'NW',max:12},
            {name:'WNW',max:12},
            {name:'W',max:12},
            {name:'WSW',max:12},
            {name:'SW',max:12},
            {name:'SSW',max:12},
            {name:'S',max:12},
            {name:'SSE',max:12},
            {name:'SE',max:12},
            {name:'ESE',max:12},
            {name:'E',max:12},
            {name:'ENE',max:12},
            {name:'NE',max:12},
            {name:'NNE',max:12}
        ],
        name:{
          textStyle:{
              color:'rgba(176,204,53,1)'
          }
        },
        axisLine: {
            lineStyle: {
                color: 'rgba(255, 255, 255, 0.4)'
            }
        },
        splitLine: {
            lineStyle: {
                color: 'rgba(255, 255, 255, 0.4)'
            }
        },
        splitArea:{
            areaStyle:{
                color:'rgba(255,255,255,0)'
            }
        }
    },
    series:[{
        type:'radar',
        data:[
            {
                value:[2.8,5.3,7.1,5.4,10.6,8.5,5.1,2.1,2.9,4.0,9.4,6.3,3.5,0.9,1,0.9],
                name:'2016'
            }
        ],
        areaStyle:{
            normal:{
                color:'rgba(176,204,53,.5)'
            }
        },
        lineStyle:{
            normal:{
                color:'rgba(176,204,53,.7)'
  
            }
        },
        symbol:'circle',
        symbolSize:6,
        itemStyle:{
            normal:{
                color:'#A9C33B'
            }
        }
    }]
  };
  var windChart=echarts.init(document.getElementById('windChart'));
  windChart.setOption(windOption);
}
